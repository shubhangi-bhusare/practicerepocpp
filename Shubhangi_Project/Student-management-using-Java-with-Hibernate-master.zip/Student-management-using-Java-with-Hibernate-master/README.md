# Student-Management-System-Using-JAVA-With-Hibernate
  Download the Archive File of this project.
  Open Eclips.
  Import this project into the Eclips. 
  Open Mysql workbench or any mysql server on your system.
  Create new Database called "demo".
  In that database Create the table students with following Query Syntax.
 # "CREATE TABLE `students` (
  # `ID` int(11) NOT NULL,
  # `FNAME` varchar(30) NOT NULL,
  # `MNAME` varchar(30) NOT NULL,
  # `LNAME` varchar(30) NOT NULL
  # ) ENGINE=InnoDB DEFAULT CHARSET=latin1;"
  Go to src\defaultpackage\hibernate folder.
  Run the following file FirstHibernateProgram.java.
